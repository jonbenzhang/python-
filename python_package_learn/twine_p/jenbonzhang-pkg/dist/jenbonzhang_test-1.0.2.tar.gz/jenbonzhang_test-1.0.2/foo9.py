import sh
def test():
    print("i'm foo91")
    a = sh.ls()
    print(a)