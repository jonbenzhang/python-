import sh
def test():
    print("i'm foo9")
    a = sh.ls()
    print(a)