import setuptools
import os




setuptools.setup(
    name="jenbonzhang_test",
    version="1.0.0",
    author="jenbonzhang",
    license='MIT License',
    author_email="jenbonzhagn@gmail.com",
    description="test package",
    long_description="test package long description",
    long_description_content_type="text/x-rst",
    url="https://github.com/jenbonzhang/chinesename",
    py_modules=['foo9'],
)

