from distutils.core import setup

setup(name='jenbonzhang_test',
      version='1.0',
      py_modules=['foo'],
      )
