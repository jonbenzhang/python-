import sh
def test():
    print("i'm foo1")
    a = sh.ls()
    print(a)